<div>
    @include('livewire.admin.sub-location.modal-form')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>
                        Sub-Location List
                        <a href="#" class="btn btn-primary btn-sm float-end" data-bs-toggle="modal"
                            data-bs-target="#AddsublocationModal">Add Sub-Location</a>
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped" id="sub_location_table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Main Location</th>
                                <th>Title</th>
                                <th>Slug</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($sub_locations as $sub_location)
                                <tr>
                                    <td>{{ $sub_location->id }}</td>
                                    <td>{{ $sub_location->location->title }}</td>
                                    <td>{{ $sub_location->title }}</td>
                                    <td>{{ $sub_location->slug }}</td>
                                    <td>{{ $sub_location->is_active ? 'Active' : 'Not Active' }}</td>
                                    <td>
                                        <!-- Edit Icon -->
                                        <a href="#" wire:click="editSubLocation({{ $sub_location->id }})" data-bs-toggle="modal" data-bs-target="#UpdatesublocationModal">
                                            <i class="fas fa-edit text-success"></i>
                                        </a>

                                        <!-- Delete Icon -->
                                        <a href="#" wire:click="deleteSubLocation({{ $sub_location->id }})" data-bs-toggle="modal" data-bs-target="#deletesublocationModal">
                                            <i class="fas fa-trash-alt text-danger"></i>
                                        </a>
                                    </td>

                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div>{{$sub_locations->links()}}</div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('script')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Handle alertify events
        window.addEventListener('alertify', event => {
            const alertifyDetail = Array.isArray(event.detail) ? event.detail[0] : event.detail;
            const { type, message } = alertifyDetail;

            if (!type || !message) {
                console.error('Type or message is missing:', alertifyDetail);
                return;
            }

            if (type === 'success') {
                alertify.success(message);
            } else if (type === 'error') {
                alertify.error(message);
            } else {
                console.error('Invalid alertify type:', type);
            }
        });
    });
</script>
@endpush


