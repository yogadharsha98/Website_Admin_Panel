<x-mail::message>


{!!$body!!}




Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
