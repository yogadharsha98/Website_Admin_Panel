@extends('layouts.admin')

@section('content')
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-header">
                        <h4>
                            Update Membership Package
                            <a href="{{ route('admin.mem_packages.index') }}" class="btn btn-primary btn-sm text-white float-end">Back</a>
                            <a href="{{ url()->current() }}" class="btn btn-info btn-sm text-white float-end mx-2">
                                Refresh
                            </a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('membership-package.update', $membership_package->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="">Title</label>
                                    <input type="text" name="name" value="{{$membership_package->package_title}}" class="form-control" />
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Status</label>
                                    <select class="form-control" id="status" name="status">
                                        <option value="1" {{ $membership_package->status == 1 ? 'selected' : '' }}>Active</option>
                                        <option value="0" {{ $membership_package->status == 0 ? 'selected' : '' }}>Inactive</option>
                                    </select>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <button type="submit" class="btn btn-success float-end">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
