@extends('layouts.admin')

@section('content')
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12">
                @if (session('success'))
                    @section('alertify-script')
                        <script>
                            alertify.success("{{ session('success') }}");
                        </script>
                    @show
                @elseif (session('failure'))
                    @section('alertify-script')
                        <script>
                            alertify.danger("{{ session('failure') }}");
                        </script>
                    @show
                @endif
                <div class="card">
                    <div class="card-header">
                        <h4>
                            Add Plan
                            <a href="" class="btn btn-primary btn-sm text-white float-end">Back</a>
                            <a href="{{ url()->current() }}" class="btn btn-info btn-sm text-white float-end mx-2">
                                Refresh
                            </a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.membership-plan.store') }}" method="POST">
                            @csrf
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="category">Category</label>
                                    <select name="category_id" id="category" class="form-select" aria-label="Default select example">
                                        <option value="" selected disabled>Select Category</option>
                                        @foreach($categories as $category)
                                            <option value="{{ $category->id }}">{{ $category->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="membership_package">Membership Package</label>
                                    <select name="membership_package_id" id="membership_package" class="form-select" aria-label="Default select example">
                                        <option value="" selected disabled>Select Membership Package</option>
                                        @foreach($membership_packages as $membership_package)
                                            <option value="{{ $membership_package->id }}">{{ $membership_package->package_title }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="">Cost Per Ad</label>
                                    <input type="number" name="cost_per_ad" id="cost_per_ad" class="form-control" oninput="calculateTotalAmount()" />
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Validity Period(In Months)</label>
                                    <input type="number" name="validity_period" id="validity_period" class="form-control" oninput="calculateTotalAmount()" />
                                    @error('validity_period')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Ads per Month</label>
                                    <input type="number" name="ads_per_month" id="ads_per_month" class="form-control" oninput="calculateTotalAmount()" />
                                    @error('ads_per_month')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Total Amount</label>
                                    <input type="text" name="total_amount" id="total_amount" class="form-control" readonly />
                                    @error('total_amount')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Status</label>
                                    <select name="is_active" class="form-select" aria-label="Default select example">
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </select>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <button type="submit" class="btn btn-success float-end">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
<script>
    function calculateTotalAmount() {
        const costPerAd = parseFloat(document.getElementById('cost_per_ad').value) || 0;
        const validityPeriod = parseFloat(document.getElementById('validity_period').value) || 0;
        const adsPerMonth = parseFloat(document.getElementById('ads_per_month').value) || 0;

        const totalAmount = costPerAd * adsPerMonth * validityPeriod;
        document.getElementById('total_amount').value = totalAmount.toFixed(2); // Display total amount as a fixed decimal
    }
</script>
@endsection
