@extends('layouts.frontend')

@section('title', 'Membership')

@section('content')
    <div>
        <section class="categories-area">
            <div class="container">
                <div class="categories-main">
                    <div class="row">
                        <!-- Full-width column for mobile number & OTP -->
                        <div class="col-12">
                            <div class="categories-right text-center">
                                <h3 class="mb-1">Unlock Adsme.lk Membership Benefits</h3>
                                <!-- Add additional content here if needed -->
                            </div>
                        </div>

                        <!-- Right column for social login -->
                        <div class="col-lg-6 col-md-12 d-flex align-items-center">
                        <label for="">Sign Up in 3 easy steps</label>
                        </div>
                    </div>

                    <style>
                        .flex {
                            display: flex;
                        }

                        .flex-col {
                            flex-direction: column;
                        }

                        .items-center {
                            align-items: center;
                        }

                        .justify-content-center {
                            justify-content: center;
                        }

                        .text-center {
                            text-align: center;
                        }

                        .mb-1 {
                            margin-bottom: 0.25rem;
                        }

                        .mb-2 {
                            margin-bottom: 0.5rem;
                        }

                        .border {
                            border: 1px solid #ccc;
                        }

                        .rounded-md {
                            border-radius: 0.375rem;
                        }

                        .p-2 {
                            padding: 0.5rem;
                        }

                        .mr-2 {
                            margin-right: 0.5rem;
                        }

                        .mail-button {
                            cursor: pointer;
                            background-color: #10b14d;
                            color: white;
                            border: none;
                        }

                        .gmail-button {
                            cursor: pointer;
                            background-color: #f7f8fa;
                            color: black;
                            border: none;
                        }

                        .fb-button {
                            cursor: pointer;
                            background-color: #007bff;
                            color: white;
                            border: none;
                        }

                        .w-full {
                            width: 100%;
                        }
                    </style>
                </div>
            </div>
        </section>
    </div>

    @push('script')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Livewire.on('alertify', alertifyDetail => {
                const { type, message } = alertifyDetail;
                if (!type || !message) {
                    console.error('Type or message is missing:', alertifyDetail);
                    return;
                }

                if (type === 'success') {
                    alertify.success(message);
                } else if (type === 'error') {
                    alertify.error(message);
                } else {
                    console.error('Invalid alertify type:', type);
                }
            });
        });
    </script>
    @endpush
@endsection
