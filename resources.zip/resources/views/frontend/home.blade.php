@extends('layouts.frontend')

@section('title', 'Adsup.lk-Electronics,Cars,Properties in Sri lanka')

@section('content')

    @if (session('success'))
        @section('alertify-script')
            <script>
                alertify.success("{{ session('success') }}");
            </script>
        @show
    @elseif (session('failure'))
        @section('alertify-script')
            <script>
                alertify.error("{{ session('failure') }}");
            </script>
        @show
    @endif



    <!-- search-section -->
    <div class="search-area">
        <div class="container">
            <div class="search-main">
                <div class="search-btn text-center">
                    <a href="#"><svg viewBox="0 0 60 60" class="svg-wrapper--8ky9e">
                            <path
                                d="M30 10c-8.4 0-15.3 6.7-15.3 15 0 4.7 2.3 10.2 6.8 16.5 3.3 4.5 6.5 7.7 6.6 7.8.5.5 1.1.7 1.8.7s1.3-.2 1.8-.7c.1-.1 3.4-3.3 6.6-7.8 4.5-6.2 6.8-11.8 6.8-16.5.2-8.3-6.7-15-15.1-15zm0 8.8c3.5 0 6.4 2.8 6.4 6.2s-2.9 6.2-6.4 6.2c-3.5 0-6.4-2.8-6.4-6.2s2.9-6.2 6.4-6.2">
                            </path>
                        </svg>All of Sri Lanka</a>
                </div>
                <div class="search-box">
                    <form action="">
                        <div class="search-input">
                            <input required type="text" placeholder="What are you looking for?">
                            <div class="search-submit">
                                <button type="submit">Search</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="categories-title text-center">
                <h4>Experience Sri Lanka’s Largest Lifetime Free Classified Ads Marketplace</h4>
                <p>Welcome to Adsup.lk! Revolutionize your online market experience in Sri Lanka. Buy, sell, or search
                    for cars, phones, property, jobs, and more. Enjoy lifetime free ads!</p>
            </div>
        </div>
    </div>

    <!-- categories-section -->
    <section class="categories-area">
        <div class="container">
            <div class="categories-main">
                <div class="row align-items-start"> <!-- Changed align-items-end to align-items-start -->
                    <div class="col-lg-5">
                        <div class="categories-left">
                            <a href="#">
                                <img src="{{ asset('frontend/images/map.svg') }}" alt="" class="img-fluid">
                                <!-- Use img-fluid for responsiveness -->
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="categories-right">
                            <h4>Browse our ad categories</h4>
                            <div class="categories-item-wrap">
                                @foreach ($categories as $category)
                                    <div class="categories-item">
                                        <a href="#">
                                            <span class="categories-img">
                                                <img src="{{ asset('storage/' . $category->image) }}"
                                                    alt="{{ $category->title }}" class="img-fluid">
                                            </span>
                                            <p>{{ $category->title }}</p>
                                            <span>({{ $category->post_count ?? 0 }}) ads</span>
                                        </a>
                                    </div>
                                @endforeach
                            </div>

                            <div class="districts-title">
                                <h4>Districts</h4>
                            </div>
                            <div class="districts-main">
                                @foreach ($locations->chunk(5) as $chunk)
                                    <div class="districts-item">
                                        <ul>
                                            @foreach ($chunk as $location)
                                                <li><a href="#">{{ $location->title }}</a></li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endforeach
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="post-main">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="post-left">
                            <div class="post-left-cnt">
                                <h3>Post Free Ad Sri Lanka<br> Just in Two Minutes</h3>
                                <ul>
                                    <li><span><i class="fa-solid fa-check"></i></i></span>Free Ads Across Categories
                                    </li>
                                    <li><span><i class="fa-solid fa-check"></i></span>Rapid Ad Publication within 4
                                        Hours</li>
                                    <li><span><i class="fa-solid fa-check"></i></span>Enhanced with 8 Photos per Ad</li>
                                    <li><span><i class="fa-solid fa-check"></i></span>Promote Ads with Top-Up | Bump-Up
                                    </li>
                                    <li><span><i class="fa-solid fa-check"></i></span>Manual Review Prevents Spam Ads
                                    </li>
                                </ul>
                                <a href="#">Post Your Ad <span>+</span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="post-right">
                            <div class="post-inner-left">
                                <img src="images/mobil4.png" alt="">
                            </div>
                            <div class="post-inner-right">
                                <h3>get your app today</h3>
                                <div><a href="#"><img src="images/pay2.svg" alt=""></a></div>
                                <div><a href="#"><img src="images/app2.svg" alt=""></a></div>
                            </div>
                        </div>
                        <div class="post-right-btm">
                            <h4>Upgrade Your Life! - Buy, Sell, and Succeed with Adsup App</h4>
                            <p>Imagine Adsup’s convenience at your fingertips! With Adsup, you can buy, sell, and search
                                with ease. Upgrade your vehicles, sell items both used and new, or find a house, land,
                                jobs, or a mobile phone. Turn your unused items into cash. If you have a service to
                                offer, Adsup makes it easy. Download your app Now</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="quick-main">
                <h4>MOST SEARCHED</h4>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="quick-item">
                            <h4>House & property</h4>
                            <ul class="inner-list">
                                <li><a href="#">House</a></li>
                                <li><a href="#">Land</a></li>
                                <li><a href="#">Apartments</a></li>
                            </ul>
                            <ul class="inner-list">
                                <li><a href="#">Annex/Rooms</a></li>
                                <li><a href="#">Commercial</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">House For Sale In Colombo</a></li>
                                <li><a href="#">Land For Sale In Kandy</a></li>
                                <li><a href="#">House for Sale in Wattala</a></li>
                                <li><a href="#">House For Sale In Kandy</a></li>
                                <li><a href="#">House For Rent In Colombo</a></li>
                                <li><a href="#">House For Sale In Gampaha</a></li>
                                <li><a href="#">Land For Sale In Colombo</a></li>
                                <li><a href="#">House for Sale in Malabe</a></li>
                                <li><a href="#">Land For Sale In Gampaha</a></li>
                                <li><a href="#">House For Rent In Kandy</a></li>
                                <li><a href="#">House For Rent In Gampaha</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="quick-item quick-item2">
                            <h4>VEHICLE</h4>
                            <ul>
                                <li><a href="#">SUVs</a></li>
                                <li><a href="#">Vans</a></li>
                                <li><a href="#">Cars</a></li>
                                <li><a href="#">Lorry</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Toyota Cars</a></li>
                                <li><a href="#">Toyota SUVs</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Honda Cars</a></li>
                                <li><a href="#">Honda SUVs</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Bajaj Threewheelers</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Yamaha Bike</a></li>
                                <li><a href="#">Suzuki Cars</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Bolero Pickup</a></li>
                                <li><a href="#">Honda Civic</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Tata Trucks</a></li>
                                <li><a href="#">Suzuki Vans</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Nissan Cars</a></li>
                                <li><a href="#">TVS Bike</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Mazda Bongo</a></li>
                                <li><a href="#">Mazda Cars</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Leyland Lorry</a></li>
                                <li><a href="#">Toyota Axio</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Honda Vezel</a></li>
                                <li><a href="#">Mazda Cars</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Motorbikes</a></li>
                                <li><a href="#">Threewheelers</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Toyota KDH</a></li>
                                <li><a href="#">Toyota Corolla</a></li>
                            </ul>

                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="quick-item">
                            <h4>electronics</h4>
                            <ul>
                                <li><a href="#">Mobile Phones & TVs</a></li>
                                <li><a href="#">Cameras & Accessories</a></li>
                                <li><a href="#">Mobile Phone Accessories</a></li>
                                <li><a href="#">Computers & Accessories</a></li>
                                <li><a href="#">Barcode Scanner & Printers</a></li>
                                <li><a href="#">Electronic Musical Instruments </a></li>
                                <li><a href="#">Audio & Video Accessories </a></li>
                                <li><a href="#">Computers & Tablets</a></li>
                                <li><a href="#">CCTV Security System</a></li>
                                <li><a href="#">Electronic Home Appliances</a></li>
                                <li><a href="#">Air Conditions & Electrical fittings</a></li>
                                <li><a href="#">Speaker & Sub Woofer</a></li>
                                <li><a href="#">Other Electronics</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="quick-item">
                            <h4>Services | Home & Garden</h4>
                            <ul>
                                <li><a href="#">Trade Services</a></li>
                                <li><a href="#">Domestic Services</a></li>
                                <li><a href="#">Travel & Tourism</a></li>
                                <li><a href="#">Bathroom & Sanitary ware</a></li>
                                <li><a href="#">Building Material & Tools</a></li>
                                <li><a href="#">Garden</a></li>
                                <li><a href="#">Kitchen items</a></li>
                                <li><a href="#">Events & Entertainment</a></li>
                                <li><a href="#">Health & Wellbeing</a></li>
                                <li><a href="#">Other Home Items</a></li>
                                <li><a href="#">Other Services</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="about-main">
                <div class="wrapper">
                    <div class="text-box">
                        <h4>About Adsup, Sri Lanka’s Fastest Growing Free Ad Marketplace</h4>
                        <p>Looking for a place to buy, sell, or rent anything in Sri Lanka? Look no further! Adsup is
                            the perfect spot for all your trading needs. We've got 15 main categories and over 60
                            subcategories, so finding the perfect item is a piece of cake.</p>
                        <p>The best part? You can post ads for free – forever! Whether you’re looking to buy, sell, or
                            rent, our user-friendly platform has got you covered. You can buy or sell a house or land,
                            find a car, purchase new or used mobile phones or any electronic items, post job listings,
                            and more.
                        </p>
                        <h4>Why Choose Adsup? Buy, Sell, Rent Almost Anything Through Adsup</h4>
                        <p>Adsup is a rapidly expanding platform for free classifieds, attracting hundreds of new users
                            each month. Whether you’re an individual or a small business owner seeking better
                            advertising options, Adsup is your ideal destination. If you’re looking to buy or sell items
                            such as smartphones, land, houses, electronics, or offer any service, Adsup is your go-to
                            destination.</p>
                        <p>Our platform is designed with unbeatable convenience in mind. The user-friendly interface
                            allows for easy searching and filtering, ensuring a seamless experience as you navigate
                            through our diverse listings. From phones and pets to cars and job opportunities, we cater
                            to a wide range of needs. We even foster a spirit of community support with our unique “give
                            away” option.</p>
                        <p>For sellers, Adsup offers a hassle-free sign-up. With a lifetime free account that can be
                            created in less than 3 minutes, showcasing your items has never been easier. And while our
                            core service remains free, we also offer a business membership with exclusive privileges.
                            This includes a personalized shop page on our site and special support to make your ads
                            stand out, making it ideal for SMEs and small businesses with multiple items to sell.</p>
                        <p>To further boost your visibility, Adsup’s Ad Network presents two paid ad promotion options.
                            These opportunities contribute to the constant growth of our platform, making Adsup not just
                            a marketplace, but a community. Join us today and experience the Adsup difference… </p>
                        <h4>Adsup’s Role in Revolutionizing Online Shopping in Sri Lanka</h4>
                        <p>In a landscape brimming with classified ad sites in Sri Lanka, many lose their free status
                            and become unaffordable as they gain popularity. It’s often said that a completely free
                            service can’t uphold quality. However, Adsup defies this notion. We pledge to provide a
                            lifetime of free advertising in Sri Lanka, ensuring service quality isn’t compromised.
                            Sounds unbelievable, doesn’t it? But that’s the Adsup promise.</p>
                        <h4>The People's Advertising Network: Adsup's User-Friendly Concept</h4>
                        <p>Adsup operates on the principle that good-quality advertising doesn’t have to come with a
                            high price tag. We strive to be the people’s advertising network. We continuously update our
                            site and apps, providing a range of features and options that make ad posting a breeze.</p>
                        <p>For instance, you can advertise almost any item for sale or rent in just three minutes using
                            our mobile apps or desktop platform, without any category restrictions. Our user-friendly
                            platform is equipped with all the standard features you need, making the advertising process
                            effortless for you..</p>
                    </div>
                    <div class="toggle_btn">
                        <span class="toggle_text">Show More</span> <span class="arrow">
                            <i class="fas fa-angle-down"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>



@endsection
