@extends('layouts.frontend')

@section('title', 'Create your Account')

@section('content')
    @if (session('success'))
        @section('alertify-script')
            <script>
                alertify.success("{{ session('success') }}");
            </script>
        @show
    @elseif (session('failure'))
        @section('alertify-script')
            <script>
                alertify.error("{{ session('failure') }}");
            </script>
        @show
    @endif
    <div>
        <section class="categories-area">
            <div class="container">
                <div class="categories-main">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="categories-right text-center">
                                <label class="mb-1">Phone Number: <strong>{{ $phoneNumber }}</strong></label>
                                <form action="{{ route('submit-name-email') }}" method="POST">
                                    @csrf
                                    <div class="flex flex-col mb-4">
                                        <div class="flex items-center mb-2">
                                            <input type="text" name="name" placeholder="Enter Your First Name"
                                                class="border rounded-md p-2 flex-grow" required />
                                        </div>
                                        <div class="flex items-center mb-2">
                                                <input type="email" name="email" placeholder="Enter Your Email"
                                                class="border rounded-md p-2 flex-grow" required />
                                        </div>
                                        <button type="submit" class="send-otp-button border rounded-md p-2">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <style>
                        .flex {
                            display: flex;
                        }

                        .flex-col {
                            flex-direction: column;
                        }

                        .items-center {
                            align-items: center;
                        }

                        .justify-content-center {
                            justify-content: center;
                        }

                        .text-center {
                            text-align: center;
                        }

                        .mb-1 {
                            margin-bottom: 0.25rem;
                        }

                        .mb-2 {
                            margin-bottom: 0.5rem;
                        }

                        .mb-4 {
                            margin-bottom: 1rem;
                        }

                        .border {
                            border: 1px solid #ccc;
                        }

                        .rounded-md {
                            border-radius: 0.375rem;
                        }

                        .p-2 {
                            padding: 0.5rem;
                        }

                        .mr-2 {
                            margin-right: 0.5rem;
                        }

                        .flex-grow {
                            flex-grow: 1;
                        }

                        .send-otp-button {
                            cursor: pointer;
                            background-color: #007bff;
                            color: white;
                            border: none;
                        }

                        .mt-3 {
                            margin-top: 0.75rem;
                        }

                        .resend-link {
                            color: #007bff;
                            text-decoration: underline;
                        }

                        h4 {
                            border-bottom: none;
                            margin-bottom: 0;
                        }
                    </style>


                </div>
            </div>
        </section>
    </div>
@endsection
