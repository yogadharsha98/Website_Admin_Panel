@extends('layouts.frontend')

@section('title', 'Sign In Page')

@section('content')
    {{-- @if (session('success'))
        @push('alertify-script')
            <script>
                alertify.success("{{ session('success') }}");
            </script>
        @endpush
    @elseif (session('error'))
        @push('alertify-script')
            <script>
                alertify.error("{{ session('error') }}");
            </script>
        @endpush
    @endif --}}
    <div>
        <section class="categories-area ">
            <div class="container">
                <div class="categories-main">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="categories-right text-center">
                                <label class="mb-1">Continue with mobile number & OTP</label>
                                <form action="{{ route('send.otp') }}" method="POST">
                                    @csrf
                                    <div class="flex flex-col mb-4">
                                        <div class="flex items-center mb-2">
                                            <select class="border rounded-md p-2 mr-2 text-center" required>
                                                <option value="+94" selected>+94 (LK)</option>
                                                <option value="+1">+1 (USA)</option>
                                                <option value="+44">+44 (UK)</option>
                                                <option value="+91">+91 (India)</option>
                                            </select>
                                            <input type="tel" name="phone_number" placeholder="Enter your mobile number"
                                                class="border rounded-md p-2 flex-grow" required />
                                            @if ($errors->has('phone_number'))
                                                <div class="text-red-500 mt-2">
                                                    {{ $errors->first('phone_number') }}
                                                </div>
                                            @endif
                                        </div>
                                        <button type="submit" class="send-otp-button border rounded-md p-2">Send
                                            OTP</button>
                                    </div>
                                </form>
                            </div>
                        </div>



                        <!-- Added OR text -->
                        <div class="col-lg-12 text-center my-3">
                            <label class="mb-1">OR</label>
                        </div>

                        <div class="col-lg-6">
                            <div class="categories-left text-center">
                                <label class="mb-1">Continue with Social Login</label>
                                <div class="flex flex-col w-full">
                                    <a href="{{ route('mail.login') }}">
                                        <button
                                            class="mail-button border rounded-md p-2 mb-2 w-full flex items-center justify-center">
                                            <img src="{{ asset('frontend/images/mail.png') }}" alt="Email Icon"
                                                class="mr-2" style="width: 20px; height: 20px;" />
                                            Continue With Email
                                        </button>
                                    </a>
                                    <a href="{{ route('google.login') }}">
                                        <button
                                            class="gmail-button border rounded-md p-2 mb-2 w-full flex items-center justify-center">
                                            <img src="{{ asset('frontend/images/gmail_1.png') }}" alt="Email Icon"
                                                class="mr-2" style="width: 20px; height: 20px;" />
                                            Continue With Gmail
                                        </button>
                                    </a>
                                    <a href="{{ route('auth.facebook') }}">
                                        <button
                                            class="fb-button border rounded-md p-2 mb-2 w-full flex items-center justify-center">
                                            <img src="{{ asset('frontend/images/facebook.png') }}" alt="Facebook Icon"
                                                class="mr-2" style="width: 20px; height: 20px;" />
                                            Continue With Facebook
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <style>
                        .flex {
                            display: flex;
                        }

                        .flex-col {
                            flex-direction: column;
                        }

                        .items-center {
                            align-items: center;
                        }

                        .justify-content-center {
                            justify-content: center;
                        }

                        .text-center {
                            text-align: center;
                            /* Center text alignment */
                        }

                        .mb-1 {
                            margin-bottom: 0.25rem;
                        }

                        .mb-2 {
                            margin-bottom: 0.5rem;
                        }

                        .mb-4 {
                            margin-bottom: 1rem;
                        }

                        .border {
                            border: 1px solid #ccc;
                        }

                        .rounded-md {
                            border-radius: 0.375rem;
                        }

                        .p-2 {
                            padding: 0.5rem;
                        }

                        .mr-2 {
                            margin-right: 0.5rem;
                        }

                        .flex-grow {
                            flex-grow: 1;
                        }

                        .send-otp-button {
                            cursor: pointer;
                            background-color: #007bff;
                            color: white;
                            border: none;
                        }

                        .mail-button {
                            cursor: pointer;
                            background-color: #10b14d;
                            color: white;
                            border: none;
                        }

                        .gmail-button {
                            cursor: pointer;
                            background-color: #f7f8fa;
                            color: black;
                            border: none;
                        }

                        .fb-button {
                            cursor: pointer;
                            background-color: #007bff;
                            color: white;
                            border: none;
                        }

                        .w-full {
                            width: 100%;
                        }

                        h4 {
                            border-bottom: none;
                            margin-bottom: 0;
                        }
                    </style>
                </div>

            </div>
        </section>
    </div>
    @push('script')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Listen for alertify events from Livewire
            Livewire.on('alertify', alertifyDetail => {
                const {
                    type,
                    message
                } = alertifyDetail;

                if (!type || !message) {
                    console.error('Type or message is missing:', alertifyDetail);
                    return;
                }

                if (type === 'success') {
                    alertify.success(message);
                } else if (type === 'error') {
                    alertify.error(message);
                } else {
                    console.error('Invalid alertify type:', type);
                }
            });
        });
    </script>
@endpush
@endsection
