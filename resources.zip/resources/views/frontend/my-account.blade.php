@extends('layouts.frontend')

@section('title', 'Home Page')

@section('content')

    <div class="container">
        <div class="post-main">
            <div class="row">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="profile-tab" data-bs-toggle="tab"
                            data-bs-target="#profile-tab-pane" type="button" role="tab"
                            aria-controls="profile-tab-pane" aria-selected="true">
                            My Profile
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="my_ads-tab" data-bs-toggle="tab" data-bs-target="#my_ads-tab-pane"
                            type="button" role="tab" aria-controls="my_ads-tab-pane" aria-selected="false">
                            My Ads
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="memberships-tab" data-bs-toggle="tab" data-bs-target="#memberships-tab-pane"
                            type="button" role="tab" aria-controls="memberships-tab-pane" aria-selected="false">
                            My Memberships
                        </button>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="profile-tab-pane" role="tabpanel"
                        aria-labelledby="profile-tab" tabindex="0">

                        <!-- Profile Update Form -->
                        <form action="{{ route('customer.update', $customer->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <div class="row">
                                <p class="mt-1"><strong>Email:</strong> {{ $customer->email }}</p>
                                <div class="col-md-6 mb-3">
                                    <label for="name">Name</label>
                                    <input type="text" name="name" id="name" value="{{ $customer->name }}"
                                        class="form-control" required />
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="phone_number">Phone Number</label>
                                    <input type="text" name="phone_number" id="phone_number"
                                        value="{{ $customer->phone_number }}" class="form-control" readonly />
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="location">Location</label>
                                    <select name="location" id="location" class="form-control" required>
                                        <option value="">Select Location</option>
                                        @foreach ($locations as $location)
                                            <option value="{{ $location->title }}"
                                                {{ $location->title == old('location', $customer->location) ? 'selected' : '' }}>
                                                {{ $location->title }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="sub_location">Sub Location</label>
                                    <select name="sub_location" id="sub_location" class="form-control" required>
                                        <option value="">Select Sub Location</option>
                                        @if ($customer->sub_location)
                                            <option value="{{ $customer->sub_location }}" selected>
                                                {{ $customer->sub_location }}
                                            </option>
                                        @elseif(old('sub_location'))
                                            <option value="{{ old('sub_location') }}" selected>{{ old('sub_location') }}
                                            </option>
                                        @endif
                                    </select>
                                </div>

                                <div class="py-2 float-end">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </div>
                        </form>

                        <form action="{{ route('customer.password', $customer->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="current_password">Current Password</label>
                                    <input type="password" name="current_password" id="current_password"
                                        class="form-control" />
                                    @if ($errors->has('current_password'))
                                        <div class="text-danger">{{ $errors->first('current_password') }}</div>
                                    @endif
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="new_password">New Password</label>
                                    <input type="password" name="new_password" id="new_password" class="form-control"
                                        required />
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="password_confirmation">Confirm Password</label>
                                    <input type="password" name="password_confirmation" id="password_confirmation"
                                        class="form-control" required />
                                </div>

                                <div class="py-2 float-end">
                                    <button type="submit" class="btn btn-primary">Update Password</button>
                                </div>
                            </div>
                        </form>
                        <!-- Delete Account and Logout Buttons -->
                        <div class="mt-4">
                            <!-- Delete Account Form -->
                            <form action="{{ route('customer.delete', $customer->id) }}" method="POST" style="display:inline;" id="delete-account-form">
                                @csrf
                                @method('DELETE')
                                <button type="button" class="btn btn-danger" onclick="confirmDeletion()">
                                    Delete Account
                                </button>
                            </form>

                            <!-- Logout Form -->
                            <form action="{{ route('logout') }}" method="POST" style="display:inline;">
                                @csrf
                                <button type="submit" class="btn btn-warning">
                                    Logout
                                </button>
                            </form>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="memberships-tab-pane" role="tabpanel" aria-labelledby="memberships-tab" tabindex="0">
                        <div class="row">
                            <div class="col-md-6 mt-1">
                                <img src="{{ asset('frontend/images/membership.png') }}" alt="Become a Member" class="img-fluid" style="width: 100px; height: 100;">
                                <h3>Become a Adsup.lk member</h3>
                                <p>Join the Adsup.lk community to enjoy exclusive benefits and get the most out of your ads experience. Get access to premium features, more visibility, and much more!</p>
                            </div>
                            <div class="col-md-6 d-flex align-items-center">
                                <button type="button" class="btn btn-info" onclick="window.location.href=''">
                                    Contact US
                                </button>
                            </div>

                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Fetch the locations and sub-locations data from Blade as a JavaScript object
            const locations = @json($locations);

            // Listen for changes in the location dropdown
            document.getElementById('location').addEventListener('change', function() {
                const locationTitle = this.value;
                const subLocationSelect = document.getElementById('sub_location');

                // Clear the sub-location dropdown
                subLocationSelect.innerHTML = '<option value="">Select Sub Location</option>';

                // Find the selected location's sub-locations
                if (locationTitle) {
                    const selectedLocation = locations.find(location => location.title == locationTitle);

                    if (selectedLocation) {
                        selectedLocation.sub_locations.forEach(subLocation => {
                            const option = document.createElement('option');
                            option.value = subLocation.title;
                            option.textContent = subLocation.title;
                            subLocationSelect.appendChild(option);
                        });
                    }
                }
            });
        });
    </script>
    <script>
        function confirmDeletion() {
            alertify.confirm("Delete Account", "Are you sure you want to delete your account? This action cannot be undone.",
                function() {
                    // If confirmed, submit the form
                    document.getElementById('delete-account-form').submit();
                },
                function() {
                    alertify.error('Account deletion cancelled');
                });
        }
    </script>
@endsection
