@extends('layouts.frontend')

@section('title', 'Verify OTP')

@section('content')
    @if (session('success'))
        @section('alertify-script')
            <script>
                alertify.success("{{ session('success') }}");
            </script>
        @show
    @elseif (session('failure'))
        @section('alertify-script')
            <script>
                alertify.error("{{ session('failure') }}");
            </script>
        @show
    @endif
    <div>
        <section class="categories-area">
            <div class="container">
                <div class="categories-main">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="categories-right text-center">
                                <label class="mb-1">Enter Your OTP for: <strong>{{ $phoneNumber }}</strong></label>
                                <form action="{{ route('verify.otp') }}" method="POST">
                                    @csrf
                                    <div class="flex flex-col mb-4">
                                        <div class="flex items-center mb-2">
                                            <input type="text" name="otp" placeholder=""
                                                class="border rounded-md p-2 flex-grow" maxlength="6" required />
                                        </div>
                                        <button type="submit" class="send-otp-button border rounded-md p-2">Submit OTP</button>
                                    </div>
                                </form>
                                <!-- Countdown timer display -->
                                <div id="timer" class="mt-3">Time left: <span id="time">60</span> seconds</div>
                                <div id="resend-container" class="mt-3" style="display: none;">
                                    <form action="{{ route('resend.otp') }}" method="POST" style="display: inline;">
                                        @csrf <!-- Include CSRF token for security -->
                                        <button type="submit" class="resend-link" style="background: none; border: none; color: blue; text-decoration: underline; cursor: pointer;">Resend Code</button>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>

                    <style>
                        .flex {
                            display: flex;
                        }

                        .flex-col {
                            flex-direction: column;
                        }

                        .items-center {
                            align-items: center;
                        }

                        .justify-content-center {
                            justify-content: center;
                        }

                        .text-center {
                            text-align: center;
                        }

                        .mb-1 {
                            margin-bottom: 0.25rem;
                        }

                        .mb-2 {
                            margin-bottom: 0.5rem;
                        }

                        .mb-4 {
                            margin-bottom: 1rem;
                        }

                        .border {
                            border: 1px solid #ccc;
                        }

                        .rounded-md {
                            border-radius: 0.375rem;
                        }

                        .p-2 {
                            padding: 0.5rem;
                        }

                        .mr-2 {
                            margin-right: 0.5rem;
                        }

                        .flex-grow {
                            flex-grow: 1;
                        }

                        .send-otp-button {
                            cursor: pointer;
                            background-color: #007bff;
                            color: white;
                            border: none;
                        }

                        .mt-3 {
                            margin-top: 0.75rem;
                        }

                        .resend-link {
                            color: #007bff;
                            text-decoration: underline;
                        }

                        h4 {
                            border-bottom: none;
                            margin-bottom: 0;
                        }
                    </style>

                    <script>
                        // Countdown timer logic
                        let timeLeft = 60; // 60 seconds

                        const timerElement = document.getElementById('time');
                        const resendContainer = document.getElementById('resend-container');

                        const countdown = setInterval(() => {
                            if (timeLeft <= 0) {
                                clearInterval(countdown);
                                timerElement.innerText = "Time's up!";
                                // Show the resend link
                                resendContainer.style.display = 'block';
                                // Optionally, disable the submit button here
                                document.querySelector('.send-otp-button').disabled = true;
                            } else {
                                timerElement.innerText = timeLeft;
                            }
                            timeLeft--;
                        }, 1000);
                    </script>
                </div>
            </div>
        </section>
    </div>
@endsection
