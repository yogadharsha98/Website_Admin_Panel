@extends('layouts.frontend')

@section('title', 'Posting Ad')

@section('content')
    <div>
        <section class="categories-area">
            <div class="container">
                <div class="categories-main">
                    <div class="row">
                        <!-- Display the logged-in customer's email -->
                        @auth('customer')
                            <div class="col-12">
                                <h3>Welcome, {{ auth('customer')->user()->email }}!</h3>
                            </div>
                        @else
                            <div class="col-12">
                                <p>Let's Post An Ad</p>
                            </div>
                        @endauth
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <p>Let's Post An Ad</p>
                        </div>
                    </div>
                    <!-- Row for Cards -->
                    <div class="row">
                        <!-- Card 1 -->
                        <div class="col-md-4">
                            <div class="card">
                                <!-- Card Header with Icon and Title -->
                                <div class="card-header d-flex align-items-center">
                                    <i class="fa fa-pen mr-2"></i> <!-- Icon (Font Awesome) -->
                                    <h5 class="card-title mb-0">Sell Something</h5> <!-- Title -->
                                </div>

                                <!-- Card Body -->
                                <div class="card-body">
                                    <!-- Link that triggers the modal -->
                                    <a href="#" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#postAdModal">
                                        Sell an item or Property
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Other Cards... -->
                    </div>
                </div>
            </div>
        </section>
    </div>

<!-- Modal for Category Selection -->
{{-- <div class="modal fade" id="postAdModal" tabindex="-1" aria-labelledby="postAdModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="postAdModalLabel">Choose Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Categories List -->
                <div class="row" id="categoryList">
                    @foreach ($categories as $category)
                        <div class="col-md-4 mb-3 category-item" data-category-id="{{ $category->id }}">
                            <!-- Category Button with Image and Title -->
                            <button class="btn btn-outline-primary w-100 d-flex align-items-center">
                                <!-- Image -->
                                <img src="{{ asset('storage/' . $category->image) }}" alt="{{ $category->title }}" class="img-fluid" style="width: 30px; height: 30px; object-fit: cover; margin-right: 10px;">
                                <!-- Category Title -->
                                <span>{{ $category->title }}</span>
                            </button>
                        </div>
                    @endforeach
                </div>


            </div>
        </div>
    </div>
</div> --}}

<!-- Modal for Category Selection -->
<div class="modal fade" id="postAdModal" tabindex="-1" aria-labelledby="postAdModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="postAdModalLabel">Choose Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Categories List in Vertical Tabs -->
                <div class="row">
                    <div class="col-md-3">
                        <!-- Vertical Tabs Navigation -->
                        <ul class="nav flex-column" id="categoryTabs" role="tablist">
                            @foreach ($categories as $category)
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="categoryTab-{{ $category->id }}" data-bs-toggle="pill" href="#category-{{ $category->id }}" role="tab" aria-controls="category-{{ $category->id }}" aria-selected="false">
                                        {{ $category->title }}
                                    </a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="col-md-9">
                        <!-- Vertical Tabs Content -->
                        <div class="tab-content" id="categoryTabsContent">
                            @foreach ($categories as $category)
                                <div class="tab-pane fade" id="category-{{ $category->id }}" role="tabpanel" aria-labelledby="categoryTab-{{ $category->id }}">
                                    <h5>{{ $category->title }} Details</h5>
                                    <!-- Subcategories for this category -->
                                    <div class="row">
                                        @foreach ($category->subcategories as $subCategory)
                                            <div class="col-md-4 mb-3">
                                                <!-- Subcategory Button (Now a Link) -->
                                                <button class="btn btn-outline-secondary w-100 subcategory-btn"
                                                        data-category-id="{{ $category->id }}"
                                                        data-subcategory-id="{{ $subCategory->id }}">
                                                    {{ $subCategory->title }}
                                                </button>
                                            </div>
                                        @endforeach
                                        @if ($category->subcategories->isEmpty())
                                            <p>No subcategories available.</p>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<!-- Add JavaScript to Handle Category Selection and Fetch Subcategories -->
@push('script')
<!-- Add this script to handle the redirect -->
<script>
    document.querySelectorAll('.subcategory-btn').forEach(button => {
        button.addEventListener('click', function () {
            var categoryId = this.getAttribute('data-category-id');
            var subCategoryId = this.getAttribute('data-subcategory-id');
            var location = '{{ $location }}'; // Get the location passed from the backend

            // Build the URL with query parameters
            var url = '{{ route("frontend.post-ad-details") }}' + '?type=for_sale&category=' + categoryId + '&subcategory=' + subCategoryId + '&location=' + location;

            // Redirect the user to the URL
            window.location.href = url;
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        Livewire.on('alertify', alertifyDetail => {
            const { type, message } = alertifyDetail;
            if (!type || !message) {
                console.error('Type or message is missing:', alertifyDetail);
                return;
            }

            if (type === 'success') {
                alertify.success(message);
            } else if (type === 'error') {
                alertify.error(message);
            } else {
                console.error('Invalid alertify type:', type);
            }
        });
    });
</script>
@endpush

@endsection
