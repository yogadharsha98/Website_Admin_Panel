<header class="header-area">
    <div class="container">
        <div class="row align-items-center">
            <!-- Left Section: Logo and Menu -->
            <div class="col-lg-6 col-8">
                <div class="header-left d-flex align-items-center">
                    <div class="mobil-burs">
                        <!-- Mobile Menu Toggle -->
                        <div class="menu-toggle">
                            <div class="menu-btn d-block d-lg-none">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </div>
                        <!-- Logo -->
                        <div class="logo-item">
                            <img src="{{ asset('frontend/images/logo.png') }}" alt="Logo">
                        </div>
                    </div>
                    <!-- Ads Links (Visible on Larger Screens) -->
                    <div class="ads-item d-none d-lg-block">
                        <ul>
                            <li><a href="#">All ads</a></li>
                            <li><a href="#">Member</a></li>
                        </ul>
                    </div>
                    <!-- Language Switcher (Visible on Larger Screens) -->
                    <div class="language-item d-none d-lg-block">
                        <ul>
                            <li><button>Sinhala</button></li>
                            <li><button>Tamil</button></li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Right Section: Navigation Links -->
            <div class="col-lg-6 col-4">
                <nav class="main-nav">
                    <ul class="d-flex align-items-center justify-content-end">
                        <!-- Message Link -->
                        <li>
                            <a href="#" aria-label="Messages">
                                <span>
                                    <i class="fa-regular fa-envelope-open"></i>
                                </span>
                                <span class="d-none d-lg-block">Message</span>
                            </a>
                        </li>
                        <li>
                            @if (Auth::guard('customer')->check())
                                <a href="{{ url('/my-account') }}" aria-label="My Account" id="myAccountButton">
                                    <span>
                                        <svg viewBox="0 0 60 60" class="svg-wrapper--8ky9e" aria-hidden="true">
                                            <path d="..."></path> <!-- Path data here -->
                                        </svg>
                                    </span>
                                    <span class="d-none d-lg-block">My Account</span>
                                </a>
                            @else
                                <a href="{{ url('/customer-sign-in') }}" aria-label="My Account" id="loginButton">
                                    <span>
                                        <svg viewBox="0 0 60 60" class="svg-wrapper--8ky9e" aria-hidden="true">
                                            <path d="..."></path> <!-- Path data here -->
                                        </svg>
                                    </span>
                                    <span class="d-none d-lg-block">Login</span>
                                </a>
                            @endif
                        </li>

                        <!-- Post Ad Link (Visible on Larger Screens) -->
                        <li class="d-none d-lg-block">
                            @auth('customer')
                                <!-- If the user is logged in, show the actual link to post an ad -->
                                <a href="{{ url('/post-ad') }}">Post Your Ad</a>
                            @else
                                <!-- If not logged in, show a link that triggers the AlertifyJS message -->
                                <a href="#" id="loginPromptLink">Post Your Ad</a>
                            @endauth
                        </li>


                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>
<!-- HEADER-SECTION-END -->

<!--MOBIL-MENU-START-->
<div class="sidebar-menu d-block d-lg-none">
    <div class="menu-header d-flex align-items-center justify-content-between">
        <div class="mobil-brand">
            <a href="#">
                <img src="{{ asset('frontend/images/logo.png') }}" alt="">
            </a>
        </div>
        <div class="close-btn">
            <span class="close-icon"></span>
        </div>
    </div>
    <div class="menu-wrap">
        <div class="menu-item"><a href="#">All ads</a></div>
        <div class="menu-item"><a href="#">Member</a></div>
    </div>
    <div class="mobil-lang">
        <ul>
            <li><button>Sinhala</button></li>
            <li><button>Tamil</button></li>
        </ul>
    </div>
</div>
<!--MOBIL-MENU-END-->

@if (request()->is('/'))
    <!-- Check if it's the homepage -->
    <!-- hero-section -->
    <div class="hero-area">
        <div class="main-content1">
            <div id="owl-csel1" class="owl-carousel owl-theme">
                <div class="slide-item">
                    <a href="#">
                        <img src="{{ asset('frontend/images/slider-2.jpg') }}" alt="">
                    </a>
                </div>
                <div class="slide-item">
                    <a href="#">
                        <img src="{{ asset('frontend/images/slider-1.jpg') }}" alt="">
                    </a>
                </div>
                <div class="slide-item">
                    <a href="#">
                        <img src="{{ asset('frontend/images/slider-2.jpg') }}" alt="">
                    </a>
                </div>
                <div class="slide-item">
                    <a href="#">
                        <img src="{{ asset('frontend/images/slider-1.jpg') }}" alt="">
                    </a>
                </div>
            </div>
            <div class="owl-theme">
                <div class="owl-controls">
                    <div class="custom-nav owl-nav"></div>
                </div>
            </div>
        </div>
    </div>
@endif
@section('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const loginPromptLink = document.getElementById('loginPromptLink');
            if (loginPromptLink) {
                loginPromptLink.addEventListener('click', function (e) {
                    e.preventDefault();  // Prevent the default action
                    // Show the AlertifyJS message
                    alertify.alert('Login Required', 'You need to be logged in to post your ad. Please log in first.', function() {
                        // Optionally, you can redirect the user to the login page after closing the alert.
                        window.location.href = '{{ url('/customer-sign-in') }}';  // Redirect to login page
                    });
                });
            }
        });
    </script>
@endsection

