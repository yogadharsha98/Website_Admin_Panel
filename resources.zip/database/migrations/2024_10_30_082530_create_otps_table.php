<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('otps', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained('customers')->onDelete('cascade'); // Reference to customers table
            $table->string('phone_number');
            $table->string('otp');
            $table->boolean('is_verified')->default(false); // To track OTP verification
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('otps'); // Drop the otps table on rollback
    }
};
