<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12">
                <?php if(session('success')): ?>
                    <?php $__env->startSection('alertify-script'); ?>
                        <script>
                            alertify.success("<?php echo e(session('success')); ?>");
                        </script>
                    <?php echo $__env->yieldSection(); ?>
                <?php elseif(session('failure')): ?>
                    <?php $__env->startSection('alertify-script'); ?>
                        <script>
                            alertify.danger("<?php echo e(session('failure')); ?>");
                        </script>
                    <?php echo $__env->yieldSection(); ?>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h4>
                            Add Plan
                            <a href="" class="btn btn-primary btn-sm text-white float-end">Back</a>
                            <a href="<?php echo e(url()->current()); ?>" class="btn btn-info btn-sm text-white float-end mx-2">
                                Refresh
                            </a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.membership-plan.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="category">Category</label>
                                    <select name="category_id" id="category" class="form-select" aria-label="Default select example">
                                        <option value="" selected disabled>Select Category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="membership_package">Membership Package</label>
                                    <select name="membership_package_id" id="membership_package" class="form-select" aria-label="Default select example">
                                        <option value="" selected disabled>Select Membership Package</option>
                                        <?php $__currentLoopData = $membership_packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($membership_package->id); ?>"><?php echo e($membership_package->package_title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="">Cost Per Ad</label>
                                    <input type="number" name="cost_per_ad" id="cost_per_ad" class="form-control" oninput="calculateTotalAmount()" />
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Validity Period(In Months)</label>
                                    <input type="number" name="validity_period" id="validity_period" class="form-control" oninput="calculateTotalAmount()" />
                                    <?php $__errorArgs = ['validity_period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Ads per Month</label>
                                    <input type="number" name="ads_per_month" id="ads_per_month" class="form-control" oninput="calculateTotalAmount()" />
                                    <?php $__errorArgs = ['ads_per_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Total Amount</label>
                                    <input type="text" name="total_amount" id="total_amount" class="form-control" readonly />
                                    <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Status</label>
                                    <select name="is_active" class="form-select" aria-label="Default select example">
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </select>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <button type="submit" class="btn btn-success float-end">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function calculateTotalAmount() {
        const costPerAd = parseFloat(document.getElementById('cost_per_ad').value) || 0;
        const validityPeriod = parseFloat(document.getElementById('validity_period').value) || 0;
        const adsPerMonth = parseFloat(document.getElementById('ads_per_month').value) || 0;

        const totalAmount = costPerAd * adsPerMonth * validityPeriod;
        document.getElementById('total_amount').value = totalAmount.toFixed(2); // Display total amount as a fixed decimal
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Classified\resources\views/admin/membership-plan/create.blade.php ENDPATH**/ ?>