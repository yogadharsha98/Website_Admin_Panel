<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- plugins:css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/mdi/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="vendors/base/vendor.bundle.base.css">
    <!-- endinject -->

    <!-- plugin css for this page -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
    <!-- End plugin css for this page -->

    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">
    <!-- endinject -->

    <link rel="shortcut icon" href="<?php echo e(asset('admin/css/images/favicon.png')); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />

    <!-- Alertify CSS -->
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css" />
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css" />

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.6/css/jquery.dataTables.min.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.6/js/jquery.dataTables.min.js">
    </script>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make('layouts.inc.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container-fluid page-body-wrapper">
            <?php echo $__env->make('layouts.inc.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="main-panel">
                <div class="content-wrapper">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
        <footer>
            Designed & Developed by Sasitharan
        </footer>
    </div>

    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        .container-scroller {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .main-panel {
            flex: 1;
        }

        .content-wrapper {
            flex: 1;
        }

        footer {
            text-align: center;
            padding: 10px;
            background-color: #f8f9fa; /* Optional background color */
            margin-top: auto; /* Push the footer to the bottom */
        }
    </style>

    <!-- plugins:js -->
    <script src="<?php echo e(asset('admin/vendors/base/vendor.bundle.base.js')); ?>"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <script src="<?php echo e(asset('admin/vendors/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <script src="<?php echo e(asset('admin/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/template.js')); ?>"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="<?php echo e(asset('admin/js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/data-table.js')); ?>"></script>

    <!-- JavaScript -->
    <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
    <script>
        alertify.set('notifier', 'position', 'top-right'); // Set global position for notifications

        window.addEventListener('alertify', event => {
            console.log('Alertify event received:', event.detail);

            const type = event.detail.type; // Get the type from event detail

            alertify.set('notifier', 'position', 'top-right'); // Set notification position

            // Check if the type is a valid AlertifyJS method before calling it
            if (typeof alertify[type] === 'function') {
                alertify[type](event.detail.message); // Show the notification
            } else {
                console.error('Invalid alertify type:', type); // Log the type for debugging
                console.error('Available types:', Object.keys(alertify)); // Log available types
            }
        });
    </script>

    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo $__env->yieldContent('alertify-script'); ?>

    <?php echo $__env->yieldPushContent('script'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\Classified\resources\views/layouts/admin.blade.php ENDPATH**/ ?>