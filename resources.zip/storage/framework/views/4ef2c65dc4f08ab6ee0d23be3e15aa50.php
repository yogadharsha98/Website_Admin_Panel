<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-header">
                        <h4>
                            Update Membership Package
                            <a href="<?php echo e(route('admin.mem_packages.index')); ?>" class="btn btn-primary btn-sm text-white float-end">Back</a>
                            <a href="<?php echo e(url()->current()); ?>" class="btn btn-info btn-sm text-white float-end mx-2">
                                Refresh
                            </a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('membership-package.update', $membership_package->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="">Title</label>
                                    <input type="text" name="name" value="<?php echo e($membership_package->package_title); ?>" class="form-control" />
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Status</label>
                                    <select class="form-control" id="status" name="status">
                                        <option value="1" <?php echo e($membership_package->status == 1 ? 'selected' : ''); ?>>Active</option>
                                        <option value="0" <?php echo e($membership_package->status == 0 ? 'selected' : ''); ?>>Inactive</option>
                                    </select>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <button type="submit" class="btn btn-success float-end">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Classified\resources\views/admin/membership-package/edit.blade.php ENDPATH**/ ?>