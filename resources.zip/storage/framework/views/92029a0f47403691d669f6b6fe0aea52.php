<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="card mt-3">
            <div class="card-body">

                <?php if(session('success')): ?>
                    <?php $__env->startSection('alertify-script'); ?>
                        <script>
                            alertify.success("<?php echo e(session('success')); ?>");
                        </script>
                    <?php echo $__env->yieldSection(); ?>
                <?php elseif(session('failure')): ?>
                    <?php $__env->startSection('alertify-script'); ?>
                        <script>
                            alertify.error("<?php echo e(session('failure')); ?>");
                        </script>
                    <?php echo $__env->yieldSection(); ?>
                <?php endif; ?>


            


                <div class="row">
                    <div class="col-md-2">
                        <div class="d-flex align-items-center bg-white border rounded-sm overflow-hidden shadow">
                            <div
                                class="p-4 bg-white d-flex justify-content-center align-items-center rounded-sm overflow-hidden shadow">
                                <img src="<?php echo e(asset('icons/application.png')); ?>" alt="Goat Icon"
                                    style="height: 30px; width: 32px;">
                            </div>
                            <div class="px-4 text-gray-700">
                                <h5 class="text-sm tracking-wider"> Categories</h5>
                                <p class="text-3xl"></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="d-flex  align-items-center bg-white border rounded-sm overflow-hidden shadow">
                            <div
                                class="p-4 bg-white d-flex justify-content-center align-items-center rounded-sm overflow-hidden shadow">
                                <img src="<?php echo e(asset('icons/categorization.png')); ?>" alt="Goat Icon"
                                    style="height: 30px; width: 32px;">
                            </div>
                            <div class="px-4 text-gray-700">
                                <h5 class="text-sm tracking-wider"> Sub Categories</h5>
                                <p class="text-3xl"></p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Classified\resources\views/home.blade.php ENDPATH**/ ?>