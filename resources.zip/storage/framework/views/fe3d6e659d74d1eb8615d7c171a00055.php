<?php $__env->startSection('title', 'Posting Ad'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <section class="categories-area">
            <div class="container">
                <div class="categories-main">
                    <!-- Row for Cards -->
                    <div class="row">
                        <!-- Card 1 -->
                        <div class="col-md-12">
                            <div class="card">
                                <!-- Card Header with Icon and Title -->
                                <div class="card-header d-flex align-items-center">
                                    <i class="fa fa-pen mr-2 ml-2"></i> <!-- Icon (Font Awesome) -->
                                    <h5 class="card-title mb-0">Fill in the details</h5> <!-- Title -->
                                </div>

                                <!-- Card Body -->
                                <div class="card-body">


                                </div>
                            </div>
                        </div>

                        <!-- Other Cards... -->
                    </div>
                </div>
            </div>
        </section>
    </div>







<!-- Add JavaScript to Handle Category Selection and Fetch Subcategories -->
<?php $__env->startPush('script'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        Livewire.on('alertify', alertifyDetail => {
            const { type, message } = alertifyDetail;
            if (!type || !message) {
                console.error('Type or message is missing:', alertifyDetail);
                return;
            }

            if (type === 'success') {
                alertify.success(message);
            } else if (type === 'error') {
                alertify.error(message);
            } else {
                console.error('Invalid alertify type:', type);
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Classified\resources\views/frontend/post-ad-details.blade.php ENDPATH**/ ?>