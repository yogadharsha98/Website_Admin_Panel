<div>
    <?php echo $__env->make('livewire.admin.location.modal-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>
                        Main Location List
                        <a href="#" class="btn btn-primary btn-sm float-end" data-bs-toggle="modal"
                            data-bs-target="#AddlocationModal">Add Main-Category</a>
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped" id="sub_category_table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Slug</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($location->id); ?></td>
                                    <td><?php echo e($location->title); ?></td>
                                    <td><?php echo e($location->slug); ?></td>
                                    <td><?php echo e($location->is_active ? 'Active' : 'Not Active'); ?></td>
                                    <td>
                                        <!-- Edit Icon -->
                                        <a href="#" wire:click="editLocation(<?php echo e($location->id); ?>)" data-bs-toggle="modal" data-bs-target="#UpdatelocationModal">
                                            <i class="fas fa-edit text-success"></i>
                                        </a>

                                        <!-- Delete Icon -->
                                        <a href="#" wire:click="deleteLocation(<?php echo e($location->id); ?>)" data-bs-toggle="modal" data-bs-target="#deletelocationModal">
                                            <i class="fas fa-trash-alt text-danger"></i>
                                        </a>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                    <div><?php echo e($locations->links()); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Handle alertify events
        window.addEventListener('alertify', event => {
            const alertifyDetail = Array.isArray(event.detail) ? event.detail[0] : event.detail;
            const { type, message } = alertifyDetail;

            if (!type || !message) {
                console.error('Type or message is missing:', alertifyDetail);
                return;
            }

            if (type === 'success') {
                alertify.success(message);
            } else if (type === 'error') {
                alertify.error(message);
            } else {
                console.error('Invalid alertify type:', type);
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>



<?php /**PATH C:\xampp\htdocs\Classified\resources\views/livewire/admin/location/index.blade.php ENDPATH**/ ?>