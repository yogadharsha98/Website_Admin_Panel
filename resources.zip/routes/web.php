<?php

use App\Livewire\MyAccountIndex;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PostAdController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\MyAccountController;
use App\Http\Controllers\EmailLoginController;
use App\Http\Controllers\MembershipController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\Admin\LoginController;
use App\Http\Controllers\Auth\GoogleController;
use App\Http\Controllers\AdminCustomerController;
use App\Http\Controllers\Auth\FacebookController;
use App\Http\Controllers\EmailRegisterController;
use App\Http\Controllers\Admin\CustomerController;
use App\Http\Controllers\Frontend\FrontendController;
use App\Http\Controllers\Admin\MembershipPlanController;
use App\Http\Controllers\Frontend\CustomerLoginController;
use App\Http\Controllers\Admin\MembershipPackageController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Livewire\Frontend\CustomerSignIn\Index as CustomerSignInIndex;
use App\Livewire\Admin\Category\Index as CategoryIndex; // Import the Category Index component
use App\Livewire\Admin\Location\Index as LocationIndex; // Import the SubCategory Index component
use App\Livewire\Admin\SubCategory\Index as SubCategoryIndex; // Import the SubCategory Index component
use App\Livewire\Admin\SubLocation\Index as SubLocationIndex; // Import the SubCategory Index component




/*
|----------------------------------------------------------------------
| Web Routes
|----------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', [FrontendController::class, 'index'])->name('frontend.home');

// Route::get('/admin', function () {
//     return redirect()->route('login');
// });

Route::get('/', [LoginController::class, 'showLoginForm'])->name('auth.login');

// Authentication routes
Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])->name('logout');

// Home route
Route::get('/home', [HomeController::class, 'index'])
    ->middleware(['auth', 'verified'])
    ->name('home');

// Profile routes
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Load authentication routes
require __DIR__ . '/auth.php';

// Admin routes
Route::group(['middleware' => ['role:super-admin|admin']], function () {

    Route::resource('permissions', PermissionController::class);
    Route::get('permissions/{permissionId}/delete', [PermissionController::class, 'destroy']);

    Route::resource('roles', RoleController::class);
    Route::get('roles/{roleId}/delete', [RoleController::class, 'destroy']);
    Route::get('roles/{roleId}/give-permissions', [RoleController::class, 'addPermissionToRole']);
    Route::put('roles/{roleId}/give-permissions', [RoleController::class, 'givePermissionToRole']);

    Route::resource('users', UserController::class);
    Route::get('users/{userId}/delete', [UserController::class, 'destroy']);

    // Admin category and sub-category routes
    Route::prefix('admin')->group(function () {
        Route::get('/category', CategoryIndex::class)->name('category.index'); // Route for Category
        Route::get('/sub-category', SubCategoryIndex::class)->name('sub-category.index'); // Route for SubCategory
        Route::get('/location', LocationIndex::class)->name('location.index'); // Route for Location
        Route::get('/sub-location', SubLocationIndex::class)->name('sub-location.index'); // Route for SubLocation
        Route::get('/customer', [CustomerController::class, 'index'])->name('admin.customer');
        Route::post('/customer/{id}/update-status', [CustomerController::class, 'updateStatus']);
        Route::delete('/customer/{id}', [CustomerController::class, 'destroy'])->name('customer.destroy');
        Route::get('/mem_packages', [MembershipPackageController::class, 'index'])->name('admin.mem_packages.index');
        Route::post('admin/mem_packages/store', [MembershipPackageController::class, 'store'])->name('admin.packages.store');
        Route::get('/membership-package/{id}/edit', [MembershipPackageController::class, 'edit'])->name('membership-package.edit');
        Route::put('/membership-package/{id}', [MembershipPackageController::class, 'update'])->name('membership-package.update');
        Route::delete('/membership-package/{id}', [MembershipPackageController::class, 'destroy'])->name('membership-package.destroy');

        Route::get('/mem_plans', [MembershipPlanController::class, 'index'])->name('admin.membership-plan.index');
        Route::get('/membership-plan/create', [MembershipPlanController::class, 'create'])->name('admin.membership-plan.create');
        Route::post('/membership-plan', [MembershipPlanController::class, 'store'])->name('admin.membership-plan.store');
        Route::get('/membership-plan/{id}/edit', [MembershipPlanController::class, 'edit'])->name('membership-plan.edit');
        Route::delete('/membership-plan/{id}', [MembershipPlanController::class, 'destroy'])->name('membership-plan.destroy');
    });

});

// Route::get('/customer-sign-in', CustomerSignInIndex::class)->name('customer-sign-in.index'); // Route for Customer Sign In
Route::post('/send-otp', [CustomerLoginController::class, 'sendOtp'])->name('send.otp');
Route::get('/verify-otp', [CustomerLoginController::class, 'verifyOtpPage'])->name('frontend.verify-otp');
Route::post('/verify-otp', [CustomerLoginController::class, 'verifyOtp'])->name('verify.otp');
Route::post('/resend-otp', [CustomerLoginController::class, 'resendOtp'])->name('resend.otp');

Route::get('/name-email-form', [CustomerLoginController::class, 'showNameEmailForm'])->name('name-email-form');
Route::post('/submit-name-email', [CustomerLoginController::class, 'submitNameEmail'])->name('submit-name-email');

Route::get('/customer-sign-in', [CustomerLoginController::class, 'index'])->name('customer-sign-in.index');
Route::get('auth/google', [GoogleController::class, 'redirectToGoogle'])->name('google.login'); // Now defined
Route::get('google-callback', [GoogleController::class, 'handleGoogleCallback']);
Route::get('auth/facebook', [FacebookController::class, 'redirectToFacebook'])->name('auth.facebook');
Route::get('facebook/callback', [FacebookController::class, 'handleFacebookCallback']);

Route::get('mail/login', [EmailLoginController::class, 'showLoginForm'])->name('mail.login');
Route::post('mail/login', [EmailLoginController::class, 'login'])->name('mail.login.submit');

Route::get('mail/register', [EmailRegisterController::class, 'showRegisterForm'])->name('mail.register');
Route::post('mail/register', [EmailRegisterController::class, 'register'])->name('mail.register.submit');
Route::get('/verify-email/{id}/{hash}', [EmailRegisterController::class, 'verifyEmail'])->name('verify.email');


Route::get('/my-account', [MyAccountController::class, 'index'])->name('my.account');
Route::put('/customer/{customer}', [MyAccountController::class, 'update'])->name('customer.update');
Route::put('/customer/{customer}/password', [MyAccountController::class, 'updatePassword'])->name('customer.password');
Route::delete('/customer/{id}/delete', [MyAccountController::class, 'delete'])->name('customer.delete');
Route::post('/logout', [MyAccountController::class, 'logout'])->name('logout');

Route::get('/post-ad', [PostAdController::class, 'showPostAdForm'])->name('post-ad');
Route::get('post-ad/details', [PostAdController::class, 'showPostAdDetails'])->name('frontend.post-ad-details');


Route::get('/membership', [MembershipController::class, 'index'])->name('membership');
