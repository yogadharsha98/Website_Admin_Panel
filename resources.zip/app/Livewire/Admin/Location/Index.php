<?php

namespace App\Livewire\Admin\Location;

use Livewire\Component;
use App\Models\Location;
use Illuminate\Support\Str;
use Livewire\WithPagination;

class Index extends Component
{

    use WithPagination;
    protected $paginationTheme = 'bootstrap';

    public function render()
    {
        $locations = Location::orderBy('title', 'ASC')->paginate(50);
        return view('livewire.admin.location.index', ['locations' => $locations])
            ->extends('layouts.admin')
            ->section('content');
    }

    public $title, $slug, $location_id;
    public $is_active = true;

    public function mount($location = null)
    {
        if ($location) {
            $this->location = $location->location_id;
            $this->title = $location->title;
            $this->slug = $location->slug;
            $this->is_active = $location->is_active;
            // Add other properties here if needed
        } else {
            // Default values for a new category
            $this->title = '';
            $this->slug = '';
            $this->is_active = true;
        }
    }

    public function storeLocation()
    {
        // Validate the inputs
        $validatedData = $this->validate([
            'title' => 'required|string|max:255',
            'slug' => 'nullable|string|max:255',
            'is_active' => 'nullable|boolean',
        ]);
        // Create the category in the database with the image path
        Location::create([
            'title' => $this->title,
            'slug' => Str::slug($this->slug), // Create a slug from the title
            'is_active' => $this->is_active ? '1' : '0', // Convert boolean to string
        ]);

        // Dispatch an alertify event after success
        $this->dispatch('alertify', [
            'type' => 'success',
            'message' => 'Location Added Successfully',
        ]);

        // Close the modal and reset the input fields
        $this->dispatch('close-modal');
        $this->resetInput();
    }

    public function closeModal()
    {
        $this->resetInput();
    }

    public function OpenModal()
    {
        $this->resetInput();
    }

    public function rules()
    {
        return [
            'title' => 'required|string',
            'slug' => 'nullable|string',
            'image' => 'nullable|string',
            'is_active' => 'nullable',
        ];
    }

    public function resetInput()
    {
        $this->title = null;
        $this->slug = null;
        $this->image = null;
        $this->is_active = null;
    }

    public function updatingPage()
    {
        $this->resetPage();
    }

    public function editLocation(int $location_id)
    {
        $this->location_id = $location_id;
        $location = Location::findOrFail($location_id);
        $this->title = $location->title;
        $this->slug = $location->slug;
        $this->is_active = $location->is_active;
    }

    public function updatedTitle($value)
    {
        // Optionally, you can still update the slug dynamically for display purposes
        $this->slug = Str::slug($value);
    }

    public function updateLocation()
    {
        // Validate inputs
        $validatedData = $this->validate([
            'title' => 'required|string|max:255',
            'is_active' => 'nullable|boolean',
        ]);

        // Update the slug based on the title before saving
        $this->slug = Str::slug($this->title);

        // Logic for updating the category
        $location = Location::findOrFail($this->location_id);

        // Prepare data for update
        $dataToUpdate = [
            'title' => $this->title,
            'slug' => $this->slug,
            'is_active' => $this->is_active ? '1' : '0',
        ];

        // Update the category
        $location->update($dataToUpdate);

        // Dispatch success alert
        $this->dispatch('alertify', [
            'type' => 'success',
            'message' => 'Location Updated Successfully',
        ]);

         // Close the modal and reset the input fields
         $this->dispatch('close-modal');
         $this->resetInput();
    }

    public function deleteLocation($location_id)
    {
        // dd($location_id);
        $this->location_id = $location_id;

    }

    public function destroyLocation()
    {
        $location = Location::find($this->location_id);
        $location->delete();
        // Dispatch an alertify event after success
        $this->dispatch('alertify', [
            'type' => 'success',
            'message' => 'Location Deleted Successfully',
        ]);
        $this->dispatch('close-modal');
    }



}
