<?php

namespace App\Livewire\Admin\SubLocation;

use Livewire\Component;
use App\Models\Location;
use App\Models\SubLocation;
use Illuminate\Support\Str;
use Livewire\WithPagination;

class Index extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';

    public function render()
    {
        $locations = Location::all();
        $sub_locations = SubLocation::orderBy('id', 'DESC')->paginate(10);
        return view('livewire.admin.sub-location.index', ['sub_locations' => $sub_locations, 'locations' => $locations])
            ->extends('layouts.admin')
            ->section('content');
    }
    public $title, $slug, $sub_location_id, $location_id;
    public $is_active = true;

    public function mount($sub_location = null)
    {
        if ($sub_location) {
            $this->sub_location = $sub_location->location_id;
            $this->sub_location = $sub_location->id;
            $this->title = $sub_location->title;
            $this->slug = $sub_location->slug;
            $this->is_active = $sub_location->is_active;
        } else {
            // Default values for a new category
            $this->title = '';
            $this->slug = '';
            $this->is_active = true;
        }
    }

    public function storeSubLocation()
    {
        // Validate the inputs
        $validatedData = $this->validate([
            'title' => 'required|string|max:255',
            'location_id' => 'required|exists:categories,id', // Validate category ID
            'slug' => 'nullable|string|max:255',
            'is_active' => 'nullable|boolean',
        ]);

        // Create the category in the database with the image path
        SubLocation::create([
            'title' => $this->title,
            'location_id' => $this->location_id,
            'slug' => Str::slug($this->slug), // Create a slug from the title
            'is_active' => $this->is_active ? '1' : '0', // Convert boolean to string
        ]);

        // Dispatch an alertify event after success
        $this->dispatch('alertify', [
            'type' => 'success',
            'message' => 'Location Added Successfully',
        ]);

        // Close the modal and reset the input fields
        $this->dispatch('close-modal');
        $this->resetInput();
    }

    public function closeModal()
    {
        $this->resetInput();
    }

    public function OpenModal()
    {
        $this->resetInput();
    }

    public function rules()
    {
        return [
            'title' => 'required|string',
            'location_id' => 'required|integer',
            'slug' => 'nullable|string',
            'is_active' => 'nullable',
        ];
    }

    public function resetInput()
    {
        $this->title = null;
        $this->slug = null;
        $this->status = null;
    }

    public function updatingPage()
    {
        $this->resetPage();
    }

    public function editSubLocation(int $sub_location_id)
    {
        $this->sub_location_id = $sub_location_id;
        $sub_location = SubLocation::findOrFail($sub_location_id);
        $this->title = $sub_location->title;
        $this->location_id = $sub_location->location_id;
        $this->slug = $sub_location->slug;
        $this->is_active = $sub_location->is_active;
    }

    public function updatedTitle($value)
    {
        // Optionally, you can still update the slug dynamically for display purposes
        $this->slug = Str::slug($value);
    }

    public function updateSubLocation()
    {
        // Validate inputs
        $validatedData = $this->validate([
            'title' => 'required|string|max:255',
            'location_id' => 'required|integer|max:255',
            'is_active' => 'nullable|boolean',
        ]);

        // Update the slug based on the title before saving
        $this->slug = Str::slug($this->title);

        // Logic for updating the category
        $sub_location = SubLocation::findOrFail($this->sub_location_id);

        // Prepare data for update
        $dataToUpdate = [
            'title' => $this->title,
            'location_id' => $this->location_id,
            'slug' => $this->slug,
            'is_active' => $this->is_active ? '1' : '0',
        ];

        // Update the category
        $sub_location->update($dataToUpdate);

        // Dispatch success alert
        $this->dispatch('alertify', [
            'type' => 'success',
            'message' => 'Sub-Location Updated Successfully',
        ]);

         // Close the modal and reset the input fields
         $this->dispatch('close-modal');
         $this->resetInput();
    }

    public function deleteSubLocation($sub_location_id)
    {
        // dd($category_id);
        $this->sub_location_id = $sub_location_id;

    }

    public function destroySubLocation()
    {
        $sub_location = SubLocation::find($this->sub_location_id);
        $sub_location->delete();
        // Dispatch an alertify event after success
        $this->dispatch('alertify', [
            'type' => 'success',
            'message' => 'Sub-Location Deleted Successfully',
        ]);
        $this->dispatch('close-modal');
    }

}
