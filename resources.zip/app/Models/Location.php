<?php

namespace App\Models;

use App\Models\SubLocation;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Location extends Model
{
    use HasFactory;

    protected $table = 'locations';

    protected $fillable = ['title', 'slug', 'is_active'];

    public static function boot()
    {
        parent::boot();

        static::creating(function ($location) {
            $location->slug = Str::slug($location->title);
        });
    }

    public function subLocations()
    {
        return $this->hasMany(SubLocation::class, 'location_id');
    }
}
