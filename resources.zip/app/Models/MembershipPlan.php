<?php

namespace App\Models;

use App\Models\Category;
use App\Models\MembershipPackage;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class MembershipPlan extends Model
{
    use HasFactory;
    protected $table = 'membership_plans';

    protected $fillable = [
        'category_id',
        'membership_package_id',
        'cost_per_ad',
        'validity_period',
        'ads_per_month',
        'total_amount',
        'is_active',
    ];

    // Define relationship to Category
    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }

    // Define relationship to MembershipPackage
    public function membershipPackage()
    {
        return $this->belongsTo(MembershipPackage::class, 'membership_package_id');
    }
}
