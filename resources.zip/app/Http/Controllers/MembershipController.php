<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MembershipController extends Controller
{
    public function index()
    {
        return view('frontend.membership'); // Ensure this points to the correct view
    }
}
