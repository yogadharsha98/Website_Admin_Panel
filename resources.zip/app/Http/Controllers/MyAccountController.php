<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Location;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class MyAccountController extends Controller
{
    public function index()
    {
        $customer = Auth::guard('customer')->user();
        $locations = Location::with('subLocations')->get(); // Load locations with related sub-locations
        return view('frontend.my-account', compact('customer', 'locations'));
    }

    public function update(Request $request, $id)
    {
        $customer = Customer::findOrFail($id);

        $customer->name = $request->name;
        $customer->phone_number = $request->phone_number;

        // Update the location and sub_location titles directly
        $customer->location = $request->location;
        $customer->sub_location = $request->sub_location;

        $customer->save();

        return back()->with('success', 'Profile updated successfully');
    }

    public function logout(Request $request)
    {
        Auth::guard('customer')->logout(); // Log out the customer

        // Optional: Invalidate the session
        $request->session()->invalidate();

        // Redirect to the home page or login page
        return redirect('/customer-sign-in')->with('status', 'Successfully logged out!'); // Add a success message
    }

    public function updatePassword(Request $request, $id)
    {
        // Validate incoming request
        $request->validate([
            'current_password' => 'required|string',
            'new_password' => 'required|string|min:6|confirmed', // Ensure password confirmation matches
        ]);

        // Find the customer by ID
        $customer = Customer::findOrFail($id);

        // Check if the current password matches the one in the database
        if (!Hash::check($request->current_password, $customer->password)) {
            // This will return the error to the form
            return redirect()->back()->withInput()->withErrors(['error' => 'The current password is incorrect.']);
        }

        // Update the password field with the new password after hashing it
        $customer->password = Hash::make($request->new_password);
        $customer->save();

        // Redirect back with a success message
        return back()->with('success', 'Password updated successfully');
    }

    public function delete($id)
    {
        try {
            // Find the customer, throw an error if not found
            $customer = Customer::findOrFail($id);

            // Delete the customer
            $customer->delete();

            // Log out the user after account deletion (optional)
            auth()->logout();

            // Redirect to home with success message
            return redirect()->route('frontend.home')->with('success', 'Your account has been deleted.');

        } catch (\Exception $e) {
            // Handle any exception, such as if the customer doesn't exist or there's a failure in deletion
            return redirect()->back()->with('error', 'There was an error deleting your account. Please try again later.');
        }
    }

}
