<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;

class GoogleController extends Controller
{
    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }

    public function handleGoogleCallback()
    {
        try {
            $googleUser = Socialite::driver('google')->stateless()->user();

            $customer = Customer::firstOrCreate(
                ['email' => $googleUser->getEmail()],
                [
                    'name' => $googleUser->getName(),
                    'social_id' => $googleUser->getId(),
                    'avatar' => $googleUser->getAvatar(),
                ]
            );

            // Log the customer in
            Auth::guard('customer')->login($customer, true); // 'true' for "remember me"

            // Redirect to the home page
            return redirect()->route('frontend.home')->with('success', 'Logged in successful!');

        } catch (\Exception $e) {
            return redirect()->route('customer-sign-in.index')->withErrors(['msg' => 'Authentication failed.']);
        }
    }
}
