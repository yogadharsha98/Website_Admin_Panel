<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Location;

class PostAdController extends Controller
{
    public function showPostAdForm()
    {
        // Fetch all categories with their subcategories
        $categories = Category::with('subCategories')->get();

        // Check if the user is authenticated as a customer using the 'customer' guard
        if (!auth()->guard('customer')->check()) {
            // Redirect to login page if the user is not authenticated as a customer
            return redirect()->route('customer.login')->with('error', 'You need to be logged in to post an ad.');
        }

        // Fetch the authenticated customer
        $customer = auth()->guard('customer')->user();

        // Get the location directly from the customer's table
        $location = $customer->location; // Assuming 'location' is a column in the 'customers' table

        // Pass categories and location to the view
        return view('frontend.post-ad', compact('categories', 'location'));
    }

    public function showPostAdDetails()
    {
        return view('frontend.post-ad-details');
    }

}
