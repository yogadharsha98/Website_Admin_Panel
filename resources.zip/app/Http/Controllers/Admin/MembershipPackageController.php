<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MembershipPackage;
use Illuminate\Http\Request;

class MembershipPackageController extends Controller
{
    public function index()
    {

        $membership_packages = MembershipPackage::all();
        return view('admin.membership-package.index', compact('membership_packages'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'package_title' => 'required|string|max:255',
            'status' => 'required|boolean',
        ]);

        MembershipPackage::create([
            'package_title' => $request->package_title,
            'status' => $request->status,
        ]);

        return redirect()->back()->with('success', 'Package added successfully');
    }

    public function edit($id)
    {
        // Retrieve the membership package by ID
        $membership_package = MembershipPackage::findOrFail($id);
        return view('admin.membership-package.edit', compact('membership_package'));
    }

    public function update(Request $request, $id)
    {
        // Validate the request data
        $request->validate([
            'name' => 'required|string|max:255',
            'status' => 'required',
        ]);

        // Find the membership package by ID
        $membership_package = MembershipPackage::findOrFail($id);
        $membership_package->update([
            'package_title' => $request->input('name'),
            'status' => $request->input('status'),
        ]);

        return redirect()->route('admin.mem_packages.index')->with('success', 'Membership package updated successfully.');
    }

    public function destroy($id)
    {
        // Find the Membership Package by ID
        $membership_package = MembershipPackage::find($id);

        // Check if the package exists
        if ($membership_package) {
            // Delete the membership package
            $membership_package->delete();

            // Return a success message and redirect
            return redirect()->back()->with('success', 'Package deleted successfully');
        }

        // If the package doesn't exist, return an error message
        return redirect()->route('membership-package.index')->with('error', 'Package not found');
    }

}
