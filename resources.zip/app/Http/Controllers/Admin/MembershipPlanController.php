<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\MembershipPackage;
use App\Models\MembershipPlan;
use Illuminate\Http\Request;

class MembershipPlanController extends Controller
{
    public function index()
    {
        $membership_plans = MembershipPlan::all();
        return view('admin.membership-plan.index',compact('membership_plans'));
    }

    public function create()
    {
        $categories = Category::where('is_active', 1)->get();
        $membership_packages = MembershipPackage::where('status', 1)->get();
        return view('admin.membership-plan.create', compact('categories', 'membership_packages'));
    }

    public function store(Request $request)
    {
        // Validate the incoming request data
        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'membership_package_id' => 'required|exists:membership_packages,id',
            'cost_per_ad' => 'required|numeric|min:0',
            'validity_period' => 'required|integer|min:1',
            'ads_per_month' => 'required|integer|min:1',
            'total_amount' => 'required|numeric|min:0',
            'is_active' => 'required|boolean',
        ]);

        try {
            // Create the new membership plan
            $plan = new MembershipPlan();
            $plan->category_id = $request->input('category_id');
            $plan->membership_package_id = $request->input('membership_package_id');
            $plan->cost_per_ad = $request->input('cost_per_ad');
            $plan->validity_period = $request->input('validity_period');
            $plan->ads_per_month = $request->input('ads_per_month');
            $plan->total_amount = $request->input('total_amount');
            $plan->is_active = $request->input('is_active');
            $plan->save();

            // Redirect back with success message
            return redirect()->route('admin.membership-plan.index')->with('success', 'Membership plan updated successfully.');

        } catch (\Exception $e) {
            // Handle any exceptions and redirect back with failure message
            return redirect()->back()->with('failure', 'An error occurred while creating the Membership Plan.');
        }
    }

    public function edit($id)
    {

        return view('admin.membership-plan.edit', compact(''));
    }

}
