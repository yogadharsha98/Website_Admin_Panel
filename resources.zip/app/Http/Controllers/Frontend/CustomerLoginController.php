<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Otp;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

// Make sure to import the correct Request class

// class CustomerLoginController extends Controller
// {
//     public function index()
//     {
//         // Logic for displaying the user's account page
//         return view('frontend.sign-in'); // Make sure this view exists
//     }

//     public function verifyOtpPage(Request $request)
//     {
//         // Get the phone number from the session (assuming you stored it during OTP sending)
//         $phoneNumber = $request->session()->get('phone_number');

//         // Logic for displaying the user's account page
//         return view('frontend.verify-otp', compact('phoneNumber')); // Pass the phone number to the view
//     }

//     public function sendOtp(Request $request)
//     {
//         // Validate the inputs using the request instance
//         $validatedData = $request->validate([
//             'phone_number' => 'required|string|max:255|regex:/^0[0-9]{9}$/',
//         ], [
//             'phone_number.regex' => 'The phone number must be in the format: 0XXXXXXXXX',
//         ]);

//         // Get the validated phone number
//         $phoneNumber = $validatedData['phone_number'];

//         // Format the phone number with the country code
//         $formattedPhoneNumber = '94' . substr($phoneNumber, 1); // This gives 94778720065

//         // Check if the phone number exists in the customers table
//         $customer = DB::table('customers')->where('phone_number', $formattedPhoneNumber)->first();

//         // Store the customer_id in the session if exists
//         if ($customer) {
//             $request->session()->put('customer_id', $customer->id); // Store the customer ID for later use
//         }

//         // Generate a random 6-digit OTP
//         $otpCode = rand(100000, 999999);

//         // Create or update the record in the database with the phone number and OTP
//         $otpRecord = Otp::updateOrCreate(
//             ['phone_number' => $formattedPhoneNumber],
//             [
//                 'otp' => $otpCode, // Store the generated OTP
//                 'is_verified' => false, // Ensure the OTP is not verified initially
//                 'created_at' => now(), // Store the current timestamp
//             ]
//         );

//         // Prepare the message with the OTP code
//         $message = "Your OTP is: $otpCode";

//         // Send OTP request using the formatted phone number with cURL
//         $ch = curl_init();
//         curl_setopt($ch, CURLOPT_URL, 'http://send.ozonedesk.com/api/v2/send.php');
//         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//         curl_setopt($ch, CURLOPT_POST, true);
//         curl_setopt($ch, CURLOPT_POSTFIELDS, [
//             'user_id' => '102255', // Hardcoded user ID for testing
//             'api_key' => 'vgjb3jbvp2wmw55ov', // Hardcoded API key for testing
//             'sender_id' => 'Adsup.lk',
//             'message' => $message, // Include the OTP in the message
//             'to' => $formattedPhoneNumber,
//         ]);

//         // Execute the cURL request
//         $response = curl_exec($ch);

//         // Check for cURL errors
//         if (curl_errno($ch)) {
//             \Log::error('cURL Error:', [
//                 'error' => curl_error($ch),
//             ]);
//             // Redirect with an error message
//             return redirect()->route('frontend.sign-in') // Change to your desired route
//                 ->with('error', 'Failed to send OTP. Please try again.');
//         }

//         // Close the cURL session
//         curl_close($ch);

//         // Decode the response to check for success
//         $responseData = json_decode($response, true);
//         \Log::info('OTP API Request:', [
//             'url' => 'http://send.ozonedesk.com/api/v2/send.php',
//             'data' => $responseData, // Log the response data as an array
//         ]);

//         // Check if the API call was successful
//         if ($responseData['status'] === 'success') {
//             // Optionally clear the phone number input
//             $request->session()->put('phone_number', $formattedPhoneNumber); // Store for later use
//             // Redirect with a success message
//             return redirect()->route('frontend.verify-otp') // Change to your desired route
//                 ->with('success', 'OTP sent successfully.');
//         } else {
//             // Log the error with the phone number included
//             \Log::error('Failed to send OTP via API:', [
//                 'response' => $responseData,
//                 'phone_number' => $formattedPhoneNumber, // Include the formatted phone number
//             ]);
//             return redirect()->route('frontend.sign-in') // Change to your desired route
//                 ->with('error', 'Failed to send OTP. Please try again.');
//         }
//     }

//     public function resendOtp(Request $request)
//     {
//         // Get the phone number from the session (assuming it's stored there after sending the OTP)
//         $phoneNumber = $request->session()->get('phone_number');

//         // Validate that the phone number exists in the session
//         if (!$phoneNumber) {
//             return redirect()->route('frontend.sign-in') // Change to your desired route
//                 ->with('error', 'No phone number found. Please request a new OTP.');
//         }

//         // Optionally, check if the phone number is in the correct format (without formatting it)
//         // You can add validation logic here if necessary

//         // Generate a new random 6-digit OTP
//         $otpCode = rand(100000, 999999);

//         // Assuming you have a way to get the customer ID
//         $customerId = auth()->user()->id; // Replace this with how you obtain the customer ID

//         // Update the record in the database with the new OTP
//         Otp::updateOrCreate(
//             ['phone_number' => $phoneNumber, 'customer_id' => $customerId], // Use the raw phone number
//             [
//                 'otp' => $otpCode, // Store the newly generated OTP
//                 'is_verified' => false, // Ensure the OTP is not verified
//                 'created_at' => now(), // Store the current timestamp
//             ]
//         );

//         // Prepare the message with the new OTP code
//         $message = "Your new OTP is: $otpCode";

//         // Send OTP request using the original phone number with cURL
//         $ch = curl_init();
//         curl_setopt($ch, CURLOPT_URL, 'http://send.ozonedesk.com/api/v2/send.php');
//         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//         curl_setopt($ch, CURLOPT_POST, true);
//         curl_setopt($ch, CURLOPT_POSTFIELDS, [
//             'user_id' => '102255', // Hardcoded user ID for testing
//             'api_key' => 'vgjb3jbvp2wmw55ov', // Hardcoded API key for testing
//             'sender_id' => 'Adsup.lk',
//             'message' => $message, // Include the new OTP in the message
//             'to' => $phoneNumber, // Use the original phone number directly
//         ]);

//         // Execute the cURL request
//         $response = curl_exec($ch);

//         // Check for cURL errors
//         if (curl_errno($ch)) {
//             \Log::error('cURL Error:', [
//                 'error' => curl_error($ch),
//             ]);
//             // Redirect with an error message
//             return redirect()->route('frontend.sign-in') // Change to your desired route
//                 ->with('error', 'Failed to resend OTP. Please try again.');
//         }

//         // Close the cURL session
//         curl_close($ch);

//         // Decode the response to check for success
//         $responseData = json_decode($response, true);
//         \Log::info('Resend OTP API Request:', [
//             'url' => 'http://send.ozonedesk.com/api/v2/send.php',
//             'data' => $responseData, // Log the response data as an array
//         ]);

//         // Check if the API call was successful
//         if ($responseData['status'] === 'success') {
//             // Redirect with a success message
//             return redirect()->back() // Go back to the previous page
//                 ->with('success', 'A new OTP has been sent successfully to ' . $phoneNumber);
//         } else {
//             // Log the error with the phone number included
//             \Log::error('Failed to resend OTP via API:', [
//                 'response' => $responseData,
//                 'phone_number' => $phoneNumber, // Include the original phone number
//             ]);
//             return redirect()->route('frontend.sign-in') // Change to your desired route
//                 ->with('error', 'Failed to resend OTP. Please try again.');
//         }
//     }

//     public function verifyOtp(Request $request)
// {
//     // Validate the OTP input
//     $request->validate([
//         'otp' => 'required|numeric|digits:6',
//     ]);

//     // Get the phone number from the session
//     $phoneNumber = $request->session()->get('phone_number');

//     // Validate that the phone number exists in the session
//     if (!$phoneNumber) {
//         return redirect()->route('frontend.sign-in')
//             ->with('error', 'No phone number found. Please request a new OTP.');
//     }

//     // Retrieve the OTP record from the database using the phone number
//     $otpRecord = Otp::where('phone_number', $phoneNumber)->first();

//     // Check if OTP record exists and if it matches
//     if ($otpRecord && $otpRecord->otp == $request->otp) {
//         // Mark the OTP as verified
//         $otpRecord->is_verified = true;
//         $otpRecord->save();

//         // Check if a customer exists with this phone number
//         $customer = Customer::where('phone_number', $phoneNumber)->first();

//         if ($customer) {
//             // Log the user in
//             Auth::guard('customer')->login($customer, true); // 'true' for "remember me"
//             return redirect()->route('frontend.home') // Adjust with the actual route name
//                 ->with('success', 'Logged in successfully.'); // Success message for existing customer
//         }

//         // Redirect to the form for name and email if the customer does not exist
//         return redirect()->route('name-email-form') // Route to new form
//             ->with('success', 'OTP verified successfully. Please provide your name and email.');
//     } else {
//         return redirect()->back()
//             ->with('error', 'Invalid OTP. Please try again.');
//     }
// }

//     public function showNameEmailForm(Request $request)
//     {
//         $phoneNumber = $request->session()->get('phone_number');

//         return view('frontend.name_email_form', compact('phoneNumber')); // Create this view
//     }
//     public function submitNameEmail(Request $request)
//     {
//         // Retrieve the phone number from the session
//         $phoneNumber = $request->session()->get('phone_number');

//         // Validate the form input
//         $request->validate([
//             'name' => 'required|string|max:255',
//             'email' => 'required|email|max:255',
//         ]);

//         // Check if a customer with the provided email already exists
//         $existingCustomer = Customer::where('email', $request->email)->first();

//         if ($existingCustomer) {
//             // If the existing customer's phone number is different
//             if ($existingCustomer->phone_number && $existingCustomer->phone_number !== $phoneNumber) {
//                 // Redirect to the sign-in page with an error message
//                 return redirect('http://localhost:8000/customer-sign-in') // Redirect to the sign-in page
//                     ->with('failure', 'Account already exists with another phone number.'); // Use with() to send failure message
//             }

//             // If the existing customer has no phone number, update it
//             if (!$existingCustomer->phone_number) {
//                 $existingCustomer->phone_number = $phoneNumber;
//                 $existingCustomer->save();
//             }

//             // Log the user in
//             Auth::guard('customer')->login($existingCustomer, true); // 'true' for "remember me"
//             return redirect()->route('frontend.home') // Adjust with the actual route name
//                 ->with('success', 'Account linked to existing email and logged in successfully.'); // Use with() for success message
//         } else {
//             // Check if the phone number is associated with any existing account
//             $customerWithPhone = Customer::where('phone_number', $phoneNumber)->first();

//             if ($customerWithPhone) {
//                 // Redirect to the sign-in page with an error message
//                 return redirect('http://localhost:8000/customer-sign-in') // Redirect to the sign-in page
//                     ->with('failure', 'Phone number already associated with another account.'); // Use with() to send failure message
//             }

//             // Create a new customer record
//             $customer = Customer::create([
//                 'name' => $request->name,
//                 'email' => $request->email,
//                 'phone_number' => $phoneNumber,
//             ]);

//             // Log the new customer in
//             Auth::guard('customer')->login($customer, true); // 'true' for "remember me"

//             // Redirect with a success message for new customer
//             return redirect()->route('frontend.home') // Adjust with the actual route name
//                 ->with('success', 'Account created successfully.'); // Use with() for success message
//         }
//     }

// }

class CustomerLoginController extends Controller
{
    public function index()
    {
        return view('frontend.sign-in'); // Ensure this view exists
    }

    public function verifyOtpPage(Request $request)
    {
        $phoneNumber = $request->session()->get('phone_number');
        return view('frontend.verify-otp', compact('phoneNumber')); // Pass the phone number to the view
    }

    public function sendOtp(Request $request)
    {
        $validatedData = $request->validate([
            'phone_number' => 'required|string|max:255|regex:/^0[0-9]{9}$/',
        ], [
            'phone_number.regex' => 'The phone number must be in the format: 0XXXXXXXXX',
        ]);

        $phoneNumber = $validatedData['phone_number'];
        $formattedPhoneNumber = '94' . substr($phoneNumber, 1); // Format the phone number

        // Check if the phone number exists in the customers table
        $customer = DB::table('customers')->where('phone_number', $formattedPhoneNumber)->first();

        if ($customer) {
            $request->session()->put('customer_id', $customer->id); // Store the customer ID for later use
        }

        // Generate a random 6-digit OTP
        $otpCode = rand(100000, 999999);

        // Create or update the record in the database
        Otp::updateOrCreate(
            ['phone_number' => $formattedPhoneNumber],
            [
                'otp' => $otpCode,
                'is_verified' => false,
                'created_at' => now(),
            ]
        );

        // Prepare and send the OTP message
        $message = "Your OTP is: $otpCode";
        $response = $this->sendOtpViaApi($formattedPhoneNumber, $message);

        // Handle API response
        if ($response['status'] === 'success') {
            $request->session()->put('phone_number', $formattedPhoneNumber);
            return redirect()->route('frontend.verify-otp')->with('success', 'OTP sent successfully.');
        } else {
            return redirect()->route('frontend.sign-in')->with('error', 'Failed to send OTP. Please try again.');
        }
    }

    protected function sendOtpViaApi($phoneNumber, $message)
    {
        // Send OTP request using cURL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://send.ozonedesk.com/api/v2/send.php');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'user_id' => '102255', // Hardcoded user ID for testing
            'api_key' => 'vgjb3jbvp2wmw55ov', // Hardcoded API key for testing
            'sender_id' => 'Adsup.lk',
            'message' => $message,
            'to' => $phoneNumber,
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true);
    }

    public function resendOtp(Request $request)
    {
        $phoneNumber = $request->session()->get('phone_number');

        if (!$phoneNumber) {
            return redirect()->route('frontend.sign-in')->with('error', 'No phone number found. Please request a new OTP.');
        }

        $otpCode = rand(100000, 999999);

        // Update the record in the database
        Otp::updateOrCreate(
            ['phone_number' => $phoneNumber],
            [
                'otp' => $otpCode,
                'is_verified' => false,
                'created_at' => now(),
            ]
        );

        $message = "Your new OTP is: $otpCode";
        $response = $this->sendOtpViaApi($phoneNumber, $message);

        if ($response['status'] === 'success') {
            return redirect()->back()->with('success', 'A new OTP has been sent successfully to ' . $phoneNumber);
        } else {
            return redirect()->route('frontend.sign-in')->with('error', 'Failed to resend OTP. Please try again.');
        }
    }

    public function verifyOtp(Request $request)
    {
        $request->validate([
            'otp' => 'required|numeric|digits:6',
        ]);

        $phoneNumber = $request->session()->get('phone_number');

        if (!$phoneNumber) {
            return redirect()->route('frontend.sign-in')->with('error', 'No phone number found. Please request a new OTP.');
        }

        $otpRecord = Otp::where('phone_number', $phoneNumber)->first();

        if ($otpRecord && $otpRecord->otp == $request->otp) {
            $otpRecord->is_verified = true;
            $otpRecord->save();

            $customer = Customer::where('phone_number', $phoneNumber)->first();

            if ($customer) {
                Auth::guard('customer')->login($customer, true);
                return redirect()->route('frontend.home')->with('success', 'Logged in successfully.');
            }

            return redirect()->route('name-email-form')->with('success', 'OTP verified successfully. Please provide your name and email.');
        } else {
            return redirect()->back()->with('error', 'Invalid OTP. Please try again.');
        }
    }

    public function showNameEmailForm(Request $request)
    {
        $phoneNumber = $request->session()->get('phone_number');
        return view('frontend.name_email_form', compact('phoneNumber')); // Create this view
    }

    public function submitNameEmail(Request $request)
    {
        $phoneNumber = $request->session()->get('phone_number');

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
        ]);

        $existingCustomer = Customer::where('email', $request->email)->first();

        if ($existingCustomer) {
            if ($existingCustomer->phone_number && $existingCustomer->phone_number !== $phoneNumber) {
                return redirect('http://localhost:8000/customer-sign-in')->with('failure', 'Account already exists with another phone number.');
            }

            if (!$existingCustomer->phone_number) {
                $existingCustomer->phone_number = $phoneNumber;
                $existingCustomer->save();
            }

            Auth::guard('customer')->login($existingCustomer, true);
            return redirect()->route('frontend.home')->with('success', 'Account linked to existing email and logged in successfully.');
        } else {
            $customerWithPhone = Customer::where('phone_number', $phoneNumber)->first();

            if ($customerWithPhone) {
                return redirect('http://localhost:8000/customer-sign-in')->with('failure', 'Phone number already associated with another account.');
            }

            // Create a new customer record
            $customer = Customer::create([
                'name' => $request->name,
                'email' => $request->email,
                'phone_number' => $phoneNumber,
            ]);

            Auth::guard('customer')->login($customer, true);
            return redirect()->route('frontend.home')->with('success', 'Account created and logged in successfully.');
        }
    }
}
