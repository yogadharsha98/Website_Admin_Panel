<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Location;

class FrontendController extends Controller
{
    public function index()
    {
        // Fetch categories and locations from the database
        $categories = Category::all(); // Adjust this query as needed
        $locations = Location::all(); // Adjust this query as needed

        // Pass the fetched data to the view
        return view('frontend.home', compact('categories', 'locations'));
    }
    public function myAccount()
    {
        // Logic for displaying the user's account page
        return view('frontend.my-account'); // Make sure this view exists
    }
}
