<?php

namespace App\Http\Requests;

use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class AnimalFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'tag_id' => [
                'required',
                'string',
                'max:255',
                'unique:animals', // Make 'tag_id' unique across all records in the 'animals' table
            ],
            'mother_tag_id' => [
                'nullable',
                'string',
                'max:255',
                'unique:animals', // Make 'mother_tag_id' unique across all records in the 'animals' table
            ],
            'father_tag_id' => [
                'nullable',
                'string',
                'max:255',
                'unique:animals', // Make 'father_tag_id' unique across all records in the 'animals' table
            ],
            'insurance_company' => 'required|string|max:255', // Updated to make it required
            'plan_name' => 'required|string|max:255', // Updated to make it required
            'policy_number' => 'required|string|max:255', // Updated to make it required
            'agent_name' => 'required|string|max:255', // Updated to make it required
            'farmer_name' => 'required|string|max:255',
            'adhar_card' => 'required|string|max:255',
            'contract_id' => 'required|string|max:255',
            'farmer_address' => 'required|string|max:255',
            'contact_number_1' => 'required|string|max:255',
            'contact_number_2' => 'required|string|max:255',
            'animal_type' => 'required|string|max:255',
            'color' => 'required|string|max:255',
            'gender' => 'required|string|max:255',
            // 'by_purchase_birth' => 'required|string|max:255',
            'contract_status' => 'required|string|max:255',
            'breed_id'  => 'required|integer'
            // 'contract_document' => 'required|string|max:255',
        ];
    }
}
