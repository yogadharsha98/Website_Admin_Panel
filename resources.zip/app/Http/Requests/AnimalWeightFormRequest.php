<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AnimalWeightFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'weight_date' => 'required|date',
            'animal_id' => 'required|exists:animals,id', // Ensure the selected animal exists
            'weight' => 'required|numeric', // Adjust as needed
            'height' => 'required|numeric', // Adjust as needed
            'remarks' => 'nullable|string', // You can add more validation rules as needed
        ];
    }
}
