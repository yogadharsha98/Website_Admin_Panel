<?php

namespace App\Http\Requests;

use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class AnimalVaccineFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'animal_id' => 'required|exists:animals,id', // Check if the selected animal_id exists in the 'animals' table.
            'vaccine_id' => 'required|exists:vaccines,id', // Check if the selected vaccine_id exists in the 'vaccines' table.
            'vaccine_date' => 'required|date',
            'valid_till' => 'required|date',
            'remarks' => 'nullable|string|max:255',
            'given_days' => 'required|integer', // Replace 'integer' with your specific validation rules for 'given_days'
        ];
    }

}
