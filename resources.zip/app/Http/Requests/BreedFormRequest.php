<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BreedFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'animal_type' => ['required', 'in:goat,sheep'], // Field is required and must be either 'goat' or 'sheep'
            'breed' => ['required', 'string'], // Field is required and must be a string
            'status' => ['required', 'in:active,inactive'], // Field is required and must be either 'active' or 'inactive'
            'male_opening_stock' => ['required', 'integer'],
             'female_opening_stock' => ['required', 'integer']
        ];
    }
}
